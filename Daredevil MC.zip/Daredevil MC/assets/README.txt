ASSETS WEBSITE DAREDEVIL MC
1. Taruh logo utama kamu sebagai: assets/logo.png
2. Taruh foto hero sebagai: assets/hero.jpg
3. Taruh foto galeri sebagai:
   gallery-01.jpg
   gallery-02.jpg
   gallery-03.jpg
   gallery-04.jpg
   gallery-05.jpg
   gallery-06.jpg
Foto galeri boleh diganti dengan URL gambar milikmu di index.html.
